<?php

//show info
phpinfo();

?>